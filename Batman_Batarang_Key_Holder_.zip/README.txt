                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2222690
Batman Batarang Key Holder  by akshay_d21 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

<h2> NA NA NA NA NA NA NA NAAAA BATMAN!</h2>

A magnetic key holder with a dash of Batman Batarangs! 

This design is compatible with <a href="https://www.amazon.com/dp/B018ITTFDM?m=AHDDZPM0CQ1RJ&ref_=v_sp_widget_detail_page/">these magnets</a> which are easily available at local re-sellers or online. I highly recommend you to use them to secure your Key holder on your fridge, door, cabinets etc. They are cheap, non-brittle and work very well too. Three magnets should do the job for this design if you have heavily loaded or metal key-chains. Two for lighter keys and key-chains. 




<br>
<i><b>Please note:</b> If you re-scale the design, you might need to add some padding/cushioning for your magnets to be placed into position.  </i>

<i>Consider supporting my designs on Patreon, here:  https://www.patreon.com/akshayd21</i>
Thank you! 



# Post-Printing

## Gluing the magnets in place

You can use any cyanoacrylate glue like <a href="https://www.amazon.com/Gorilla-Glue-Adhesive-2-Ounces-50001/dp/B0007KQUMK/ref=sr_1_9?s=office-products&ie=UTF8&qid=1508270753&sr=1-9&keywords=gorilla+glue/">Gorilla Glue</a> like I did or super glue gel like <a href="https://www.amazon.com/Loctite-Super-Control-Bottle-1364076-6/dp/B01N2S50HN/ref=sr_1_1_sspa?ie=UTF8&qid=1508270705&sr=8-1-spons&keywords=loctite+glue&psc=1/">Loctite Gel Control</a> that cures over 24-48 hours for long lasting bond.