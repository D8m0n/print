                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:3092503
Retro Rocket Planter / Pencil Cup by printfutura is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Retro Rocket Planter that prints well in a variety of sizes. Perfect for bringing some sci-fi flair to your desk or garden!

85% scale works great as a pencil/marker cup or desk organizer.
50% scale is great for single small plant or for propagating succulents.

A single drain hole is located at the base, a variant without a drain hole is also available for download. 

Designed to print without supports, recommended print orientation is upside-down.

A 4-fin variant of the rocket planter is also available for additional stability if your plant is top heavy. 

 



# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: Doesn't Matter
Supports: No
Resolution: 0.3
Infill: 18
Filament_brand: Filamentum
Filament_color: Vertigo Grey
Filament_material: PLA

Notes: 
Use brim for additional bed adhesion if needed.