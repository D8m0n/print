                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3417179
Extra Wide Playing Card Holder by abelsm2 is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a playing card holder intended for people who are either unable to hold cards anymore or simply can't hold as many cards as needed for the game they play.  I designed it for my grandfather who can't hold the cards long enough to finish his favorite game.  I had a version that said "GRANDPA" on the front (facing the player) but I removed the text when uploading it for this thing.  It did look really nice if you're looking for a gift idea.

There are many playing card holders out there but I didn't see any that would comfortably hold enough cards to play "May I" (a.k.a., Continental Rummy), in which you can have as many as 17 cards in your hand.  I also didn't like how most of them held the cards vertically so this one tilts the cards back slightly for easier reading when you place it right in front of you.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK3
Rafts: No
Supports: No
Resolution: .2 mm
Infill: 10% gyroid

Notes: 
The one in the photo is printed in Atomic Silver Metallic PETG but I would imagine any type of filament will work just fine.  You can really print this any way you want since there are no supports and the geometry is very simple.  I designed this to be as large as possible and still fit on the bed of a Prusa MK3 (210 x 250) so you need to ensure it fits properly on your bed.  Be careful if you scale this down to fit, since the gap that holds the cards may start to get too thin to easily insert the cards.