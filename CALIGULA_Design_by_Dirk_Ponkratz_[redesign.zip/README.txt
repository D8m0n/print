                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3349945
CALIGULA (Design by Dirk Ponkratz) [redesign] by JaWu is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

The slingshot I'm presenting here is based on the design of my German slingshot friend, Dirk Ponkratz. 

The stl-file is based on a hand sketch and some photos of Dirk.
The challenge here is that this slingshot will not brew a flat footprint for printing. If you want to print this slingshot, you should intensively work with the support structure function of your slicer program.

And now have fun and post your makes.

And don't forget to check my other designs!

# Print Settings

Printer Brand: Creality
Printer: Ender 2
Rafts: No
Supports: Yes
Resolution: 0,1mm
Infill: 60
Filament_brand: Good and cheap
Filament_material: PLA

Notes: 
5 lines for wall
25 solid top and bottom layer
Nozzle 0,4mm

You will need support to print the slots! Also for the curved handle.
The support is a challenge!

# Post-Printing

It is recommended to sand the sling after printing (down to 1000 grit). ABS would be steamed on acetone.