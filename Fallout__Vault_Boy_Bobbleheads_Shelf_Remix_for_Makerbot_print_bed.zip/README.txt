                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2492739
Fallout : Vault Boy Bobbleheads Shelf (Remix for Makerbot print bed) by Daveon is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a Remix of  nasooralj's "Fallout: Vault Boy Bobbleheads Shelf" that has been cut into pieces suitable to be printed on a Makerbot Replicator print bed.   The original model was 12" wide, which is too large to print on a standard Makerbot Replicator.  At the same time, 12" is too narrow to comfortably fit seven Fallout 4 bobbleheads on a single row.  

Parts have been successfully print tested on a Replicator Dual and Replicator+.

No supports are required with the default orientation, but may be needed for some slight overhang if you change rotation. 

For the rectangular parts, you only need to print either the solid OR the hollow part, you do not need both.  If you choose to print the 6 solid pieces instead of the hollow parts, I would recommend using minfill or equivalent.  If your software does not have a minfill option, then I did test with 10% infill, but 5% should be strong enough.

If you choose to use the hollow versions for those parts, you will need to print 2 base caps for the underside of the bottom back parts as well.  (Caps will not be required for the top or middle pieces as these will be hidden by the adjoining parts).   

Follow the layout images for placement.

A full print with rafts may require 1.8 kg of filament or more.

Once assembled (parts will need to be glued together and filler such as milliput will be needed to hide seams) total dimensions of this resized and split version of the shelf are  15" wide x 10.7" deep x 7.9" tall.   (381mm X 272.4mm X 201.7mm).