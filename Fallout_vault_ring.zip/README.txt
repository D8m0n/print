                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2436474
Fallout vault ring by Kossel2020Ownermaker is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

I found a ring of fallout on sale for 99$ It's looking good so i challenge myself to reproduce it :D 
And this is what i succes to do. I printed it face up. Fit good for my finger but maybe you will need to scale it down or up. I mesure my finger 20mm diameter but i need a 23mm ring to be eable to wear it and be comfortable.

**I found that the background of the gear was a little bit too thin soo i change it in the fallout ring v1.1 and i add same ring  but smaller inside 22.5mm.

*I add my Autodesk 123d design file to show how i made this and if you want to remake/remix it ... 
*If you print it, I would enjoy seeing the result. Do not hesitate to give your comments and if you have any suggestions I am ready to make modifications

# Print Settings

Printer: folgertech
Rafts: Doesn't Matter
Supports: Doesn't Matter

Notes: 
I printed it face up to have better result .. printing it face down will make bridge under the number (so you see clearly the filament) and this is looking weird.